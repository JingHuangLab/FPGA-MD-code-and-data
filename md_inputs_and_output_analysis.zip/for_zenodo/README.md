# Scripts and coordinates of input, results


├── cpu_results
│   └── energy_force_test
│       ├── analytical
│       ├── argon
│       └── dhfr_amber
├── fpga_results
│   └── energy_force_test
│       ├── analytical
│       ├── argon
│       └── dhfr_charmm
├── gpu_results
│   └── energy_force_test
│       ├── analytical
│       ├── argon
│       └── dhfr_amber
├── gpu_results_single
│   └── energy_force_test
│       ├── analytical
│       ├── argon
│       └── dhfr_amber
├── md
│   ├── dhfr.pdb
│   ├── fpga
│   ├── gpu_dp
│   ├── gpu_sp
│   └── results
└── plot

