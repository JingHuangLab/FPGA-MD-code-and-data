# Md Uni Fpga Dev

This project directory structure is designed for FPGA development, particularly for the F37X accelerator. Below is an overview of the primary directories and their purposes:

| Directory       | Description                                                                                               |
| :-------------- | :-------------------------------------------------------------------------------------------------------- |
| **board_files** | Stores board information files for the F37X accelerator.                                                 |
| **build**       | Contains compiled FPGA project files. Files here are typically not version-controlled. Final releases are archived and uploaded to this directory. |
| **constr**      | Holds constraint files (e.g., XDC, UCF) required for FPGA compilation.                           |
| **doc**         | Stores project-specific design documents, specifications, and development notes.                          |
| **refer**       | Contains reference materials, including external Git repositories or uploaded files for documentation.    |
| **script**      | Includes scripts for project automation, such as rebuilding the project or auxiliary tools.       |
| **sim**         | Houses simulation-related code and test cases (e.g., testbenches, simulation scripts).           |
| **src**         | Contains the primary FPGA design source code (e.g., Verilog, VHDL, SystemVerilog files).          |
| **test**        | Stores downloadable test files or engineering versions for debugging specific interface functionalities. |
| **tools**       | Holds project-specific tools, links to external Git modules, or drivers for software applications.       |

### Key Notes:
- **Version Control**: The `build` directory is generally excluded from version control to avoid redundancy. Only final release archives should be uploaded.
- **Constraint Files**: These define physical pin mappings and timing constraints crucial for hardware implementation.
- **Simulation**: The `sim` directory supports verification through testbenches and scripts, ensuring design correctness.
- **Documentation**: Use `doc` for project-specific documents and `refer` for external references or shared resources.

This structure promotes organization, scalability, and collaboration in FPGA development. For detailed guidelines on FPGA design practices, refer to the linked resources.

: This directory structure is inspired by common FPGA project organizations, which often include separate directories for benchmarks, configs, scripts, and documentation to ensure clarity and maintainability.  
: The `src`, `constr`, `sim`, and `doc` directories align with recommended practices for ZYNQ and general FPGA development, ensuring logical separation of source code, constraints, simulation files, and documentation.  
: The `sim` directory typically contains testbenches and simulation scripts, which are critical for verifying HDL designs.  
: Constraint files (e.g., XDC) are essential for defining FPGA pin mappings and timing constraints.  
: Simulation directories often include scripts and testbenches to validate design functionality.  
: Well-structured documentation and constraint management are key to efficient FPGA development.  
: The `build` directory is commonly excluded from version control to avoid storing generated files.